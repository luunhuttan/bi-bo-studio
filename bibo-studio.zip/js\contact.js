// Form validation and handling
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    if (!contactForm) return;

    // Form validation
    const validateForm = (formData) => {
        const errors = {};
        
        // Validate name
        if (!formData.get('name').trim()) {
            errors.name = 'Vui lòng nhập tên của bạn';
        }
        
        // Validate phone
        const phone = formData.get('phone').trim();
        if (!phone) {
            errors.phone = 'Vui lòng nhập số điện thoại';
        } else if (!/^[0-9]{10,11}$/.test(phone.replace(/\s+/g, ''))) {
            errors.phone = 'Số điện thoại không hợp lệ';
        }
        
        // Validate message
        if (!formData.get('message').trim()) {
            errors.message = 'Vui lòng nhập lời nhắn';
        }
        
        return errors;
    };

    // Show error message
    const showError = (input, message) => {
        const formGroup = input.closest('.form-group');
        const errorDiv = formGroup.querySelector('.error-message') || document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        
        if (!formGroup.querySelector('.error-message')) {
            formGroup.appendChild(errorDiv);
        }
        
        input.classList.add('error');
    };

    // Clear error message
    const clearError = (input) => {
        const formGroup = input.closest('.form-group');
        const errorDiv = formGroup.querySelector('.error-message');
        if (errorDiv) {
            errorDiv.remove();
        }
        input.classList.remove('error');
    };

    // Add input event listeners for real-time validation
    contactForm.querySelectorAll('input, textarea').forEach(input => {
        input.addEventListener('input', () => {
            clearError(input);
        });
        
        input.addEventListener('blur', () => {
            const formData = new FormData(contactForm);
            const errors = validateForm(formData);
            if (errors[input.name]) {
                showError(input, errors[input.name]);
            }
        });
    });

    // Form submission
    contactForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const errors = validateForm(formData);
        
        // Clear all previous errors
        this.querySelectorAll('.error-message').forEach(error => error.remove());
        this.querySelectorAll('.error').forEach(input => input.classList.remove('error'));
        
        // Show new errors if any
        if (Object.keys(errors).length > 0) {
            Object.entries(errors).forEach(([field, message]) => {
                const input = this.querySelector(`[name="${field}"]`);
                if (input) {
                    showError(input, message);
                }
            });
            return;
        }
        
        // Show loading state
        const submitButton = this.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;
        submitButton.disabled = true;
        submitButton.innerHTML = '<span class="spinner"></span> Đang gửi...';
        
        try {
            // Here you would typically send the data to your server
            // For now, we'll simulate an API call
            await new Promise(resolve => setTimeout(resolve, 1500));
            
            // Show success message
            const successMessage = document.createElement('div');
            successMessage.className = 'success-message';
            successMessage.textContent = 'Cảm ơn bạn đã liên hệ! Chúng tôi sẽ phản hồi sớm nhất có thể.';
            
            // Insert success message after form
            this.insertAdjacentElement('afterend', successMessage);
            
            // Reset form
            this.reset();
            
            // Remove success message after 5 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 5000);
            
        } catch (error) {
            // Show error message
            const errorMessage = document.createElement('div');
            errorMessage.className = 'error-message global-error';
            errorMessage.textContent = 'Có lỗi xảy ra. Vui lòng thử lại sau.';
            
            // Insert error message after form
            this.insertAdjacentElement('afterend', errorMessage);
            
            // Remove error message after 5 seconds
            setTimeout(() => {
                errorMessage.remove();
            }, 5000);
            
        } finally {
            // Reset button state
            submitButton.disabled = false;
            submitButton.textContent = originalText;
        }
    });
});

// Add styles for form validation
const contactStyle = document.createElement('style');
contactStyle.textContent = `
    .form-group {
        position: relative;
        margin-bottom: 1.5rem;
    }
    
    .error-message {
        color: #dc3545;
        font-size: 0.875rem;
        margin-top: 0.25rem;
    }
    
    .error {
        border-color: #dc3545 !important;
    }
    
    .success-message {
        background-color: #d4edda;
        color: #155724;
        padding: 1rem;
        border-radius: 5px;
        margin-top: 1rem;
        text-align: center;
    }
    
    .global-error {
        background-color: #f8d7da;
        color: #721c24;
        padding: 1rem;
        border-radius: 5px;
        margin-top: 1rem;
        text-align: center;
    }
    
    .spinner {
        display: inline-block;
        width: 1rem;
        height: 1rem;
        border: 2px solid #fff;
        border-radius: 50%;
        border-top-color: transparent;
        animation: spin 1s linear infinite;
        margin-right: 0.5rem;
    }
    
    @keyframes spin {
        to {
            transform: rotate(360deg);
        }
    }
`;

document.head.appendChild(contactStyle); 